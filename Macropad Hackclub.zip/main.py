from machine import Pin


button0 = Pin(2, Pin.IN, Pin.PULL_UP) 
button1 = Pin(3, Pin.IN, Pin.PULL_UP)
button2 = Pin(4, Pin.IN, Pin.PULL_UP) 
button3 = Pin(5, Pin.IN, Pin.PULL_UP)
button4 = Pin(6, Pin.IN, Pin.PULL_UP) 
button5 = Pin(7, Pin.IN, Pin.PULL_UP)

while True:
    if(button0.value() == 0):
        print("0")
        # this now successfully handles button presses|
        # The microcontroller shown on THE BIN is a picoW
        # The next stage of this project requires connecting to my local api
        # Wokwi does not have support for Wifi boards i believe
        
        # I plan to turn this into a macropad to control lighting, power
        # and various other functions for my desk
    elif(button1.value() == 0):
        print("1")
    elif(button2.value() == 0):
        print("2")
    elif(button3.value() == 0):
        print("3")
    elif(button4.value() == 0):
        print("4")
    elif(button5.value() == 0):
        print("5")
    
